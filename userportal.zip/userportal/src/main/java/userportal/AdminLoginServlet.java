package userportal;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AdminLoginServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    String email = req.getParameter("email");
    String password = req.getParameter("password");

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_steps", "root", "younus");

      PreparedStatement ps = con.prepareStatement("SELECT * FROM admindata WHERE email=? AND password=?");
      ps.setString(1, email);
      ps.setString(2, password);
      ResultSet rs = ps.executeQuery();

      if (rs.next()) {
        res.sendRedirect("admindashboard");
      } else {
        res.getWriter().println("<script>alert('Invalid admin credentials'); window.location='adminlogin.html';</script>");
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
