package userportal;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EditServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException {

    String email = req.getParameter("email");

   
    PrintWriter  pw = res.getWriter();

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection(
          "jdbc:mysql://localhost:3306/jdbc_steps", "root", "younus");

      PreparedStatement ps = con.prepareStatement("SELECT * FROM userdata WHERE email=?");
      ps.setString(1, email);
      ResultSet rs = ps.executeQuery();

      if (rs.next()) {
    	  pw.println("<html>");
    	  pw.println("<head>");
    	  pw.println("<title>Edit User</title>");
    	  pw.println("<style>");
    	  pw.println("body { margin: 0; padding: 0; background: linear-gradient(to right, #fbc2eb, #a6c1ee); font-family: 'Segoe UI', sans-serif; }");
    	  pw.println(".card { background: white; max-width: 500px; margin: 60px auto; padding: 30px; border-radius: 12px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); text-align: center; }");
    	  pw.println("h2 { color: #333; margin-bottom: 25px; }");
    	  pw.println("input { width: 90%; padding: 10px; margin: 10px 0; border-radius: 6px; border: 1px solid #ccc; font-size: 16px; }");
    	  pw.println("input[readonly] { background-color: #f0f0f0; }");
    	  pw.println("button { margin-top: 20px; padding: 10px 25px; background-color: #4CAF50; color: white; border: none; border-radius: 6px; font-size: 16px; cursor: pointer; }");
    	  pw.println("button:hover { opacity: 0.9; }");
    	  pw.println("</style>");
    	  pw.println("</head>");
    	  pw.println("<body>");
    	  pw.println("<div class='card'>");

    	  pw.println("<h2>Edit User Details</h2>");
    	  pw.println("<form action='update' method='post'>");

    	  pw.println("<input type='text' name='name' value='" + rs.getString("name") + "' placeholder='Name' required><br>");
    	  pw.println("<input type='email' name='email' value='" + rs.getString("email") + "' readonly><br>");
    	  pw.println("<input type='password' name='password' value='" + rs.getString("password") + "' placeholder='Password' required><br>");
    	  pw.println("<input type='text' name='mobile' value='" + rs.getString("mobile") + "' placeholder='Mobile Number' required><br>");

    	  pw.println("<button type='submit'>Update</button>");
    	  pw.println("</form>");

    	  pw.println("</div>");
    	  pw.println("</body></html>");
      } else {
    	  pw.println("<script>alert('User not found'); window.location='login.html';</script>");
      }

      con.close();
    } catch (Exception e) {
      e.printStackTrace();
      pw.println("<script>alert('Something went wrong'); window.location='login.html';</script>");
    }
  }
}
