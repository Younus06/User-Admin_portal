package userportal;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RegisterServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    String name = req.getParameter("name");
    String email = req.getParameter("email");
    String password = req.getParameter("password");
    String mobile = req.getParameter("mobile");

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_steps", "root", "younus");
      PreparedStatement ps = con.prepareStatement("INSERT INTO userdata VALUES (?, ?, ?, ?)");
      ps.setString(1, name);
      ps.setString(2, email);
      ps.setString(3, password);
      ps.setString(4, mobile);
      ps.executeUpdate();
      con.close();
      res.sendRedirect("login.html");
    } catch (Exception e) {
      e.printStackTrace();
      res.getWriter().println("Error during registration.");
    }
  }
}
