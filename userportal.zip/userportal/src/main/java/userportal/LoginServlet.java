package userportal;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException {

    String email = req.getParameter("email");
    String password = req.getParameter("password");
    PrintWriter  pw = res.getWriter();

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection(
          "jdbc:mysql://localhost:3306/jdbc_steps", "root", "younus");

      PreparedStatement ps = con.prepareStatement(
          "SELECT * FROM userdata WHERE email=? AND password=?");
      ps.setString(1, email);
      ps.setString(2, password);
      ResultSet rs = ps.executeQuery();

      if (rs.next()) {
    	  pw.println("<html>");
    	  pw.println("<head>");
    	  pw.println("<title>User Details</title>");
    	  pw.println("<style>");
    	  pw.println("body { margin: 0; padding: 0; background: linear-gradient(to right, #f78ca0, #f9748f); font-family: 'Segoe UI', sans-serif; }");
    	  pw.println(".card { background: white; max-width: 500px; margin: 60px auto; padding: 30px; border-radius: 12px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); text-align: center; }");
    	  pw.println("h2 { color: #333; margin-bottom: 25px; }");
    	  pw.println("p { font-size: 18px; color: #555; margin: 10px 0; }");
    	  pw.println(".button-row { display: flex; justify-content: center; gap: 20px; margin-top: 30px; }");
    	  pw.println(".btn { padding: 10px 20px; border: none; border-radius: 6px; font-size: 16px; cursor: pointer; font-weight: bold; }");
    	  pw.println(".edit-btn { background-color: #3498db; color: white; }");
    	  pw.println(".delete-btn { background-color: #e74c3c; color: white; }");
    	  pw.println(".btn:hover { opacity: 0.9; }");
    	  pw.println("</style>");
    	  pw.println("</head>");
    	  pw.println("<body>");
    	  pw.println("<div class='card'>");

    	  pw.println("<h2>User Details</h2>");
    	  pw.println("<p><strong>Name:</strong> " + rs.getString("name") + "</p>");
    	  pw.println("<p><strong>Email:</strong> " + rs.getString("email") + "</p>");
    	  pw.println("<p><strong>Password:</strong> ******</p>");
    	  pw.println("<p><strong>Mobile:</strong> " + rs.getString("mobile") + "</p>");

    	  pw.println("<div class='button-row'>");

    	  pw.println("<form action='edit' method='post'>");
    	  pw.println("<input type='hidden' name='email' value='" + rs.getString("email") + "'>");
    	  pw.println("<button type='submit' class='btn edit-btn'>Edit</button>");
    	  pw.println("</form>");

    	  pw.println("<form action='delete' method='post' onsubmit=\"return confirm('Are you sure to delete this account?');\">");
    	  pw.println("<input type='hidden' name='email' value='" + rs.getString("email") + "'>");
    	  pw.println("<button type='submit' class='btn delete-btn'>Delete</button>");
    	  pw.println("</form>");

    	  pw.println("</div>"); 
    	  pw.println("</div>"); 
    	  pw.println("</body></html>");
      } else {
    	  pw.println("<script>alert('Invalid credentials'); window.location='login.html';</script>");
      }

      con.close();
    } catch (Exception e) {
      e.printStackTrace();
      pw.println("<script>alert('An error occurred. Please try again.'); window.location='login.html';</script>");
    }
  }
}
