package userportal;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DeleteServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    String email = req.getParameter("email");

    res.setContentType("text/html");
    PrintWriter out = res.getWriter();

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_steps", "root", "younus");

      PreparedStatement ps = con.prepareStatement("DELETE FROM userdata WHERE email=?");
      ps.setString(1, email);
      int rows = ps.executeUpdate();

      if (rows > 0) {
        out.println("<script>alert('Account deleted successfully!'); window.location='index.html';</script>");
      } else {
        out.println("<script>alert('User not found or already deleted'); window.location='login.html';</script>");
      }

      con.close();
    } catch (Exception e) {
      e.printStackTrace();
      out.println("<script>alert('Error while deleting.'); window.location='login.html';</script>");
    }
  }
}
