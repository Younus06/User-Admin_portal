package userportal;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class UpdateServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException {

    String name = req.getParameter("name");
    String email = req.getParameter("email");
    String password = req.getParameter("password");
    String mobile = req.getParameter("mobile");

    res.setContentType("text/html");
    PrintWriter  pw = res.getWriter();

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection(
          "jdbc:mysql://localhost:3306/jdbc_steps", "root", "younus");

      PreparedStatement ps = con.prepareStatement("UPDATE userdata SET name=?, password=?, mobile=? WHERE email=?");
      ps.setString(1, name);
      ps.setString(2, password);
      ps.setString(3, mobile);
      ps.setString(4, email);

      int i = ps.executeUpdate();

      if (i > 0) {
        PreparedStatement ps2 = con.prepareStatement( "SELECT * FROM userdata WHERE email=?");
        ps2.setString(1, email);
        ResultSet rs = ps2.executeQuery();

        if (rs.next()) {
        	 pw.println("<html>");
        	 pw.println("<head>");
        	 pw.println("<title>Updated Details</title>");
        	 pw.println("<style>");
        	 pw.println("body { margin: 0; padding: 0; background: linear-gradient(to right, #74ebd5, #9face6); font-family: 'Segoe UI', sans-serif; }");
        	 pw.println(".card { background: white; max-width: 500px; margin: 60px auto; padding: 30px; border-radius: 12px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); text-align: center; }");
        	 pw.println("h2 { color: #333; margin-bottom: 25px; }");
        	 pw.println("p { font-size: 18px; color: #555; margin: 10px 0; }");
        	 pw.println(".btn { margin-top: 30px; padding: 10px 25px; background-color: #4CAF50; color: white; border: none; border-radius: 6px; font-size: 16px; cursor: pointer; }");
        	 pw.println(".btn:hover { opacity: 0.9; }");
        	 pw.println("</style>");
        	 pw.println("</head>");
        	 pw.println("<body>");
        	 pw.println("<div class='card'>");

        	 pw.println("<h2>Updated User Details</h2>");
        	 pw.println("<p><strong>Name:</strong> " + rs.getString("name") + "</p>");
        	 pw.println("<p><strong>Email:</strong> " + rs.getString("email") + "</p>");
        	 pw.println("<p><strong>Password:</strong> ******</p>");
        	 pw.println("<p><strong>Mobile:</strong> " + rs.getString("mobile") + "</p>");

        	 pw.println("<a href='login.html'><button class='btn'>Back to Login</button></a>");

        	 pw.println("</div>");
        	 pw.println("</body></html>");
        }
      } else {
    	  pw.println("<script>alert('Update failed'); window.location='login.html';</script>");
      }

      con.close();
    } catch (Exception e) {
      e.printStackTrace();
      pw.println("<script>alert('Something went wrong'); window.location='login.html';</script>");
    }
  }
}
