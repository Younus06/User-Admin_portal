package userportal;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AdminDashboardServlet extends HttpServlet {
  protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    res.setContentType("text/html");
    PrintWriter pw = res.getWriter();

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_steps", "root", "younus");
      Statement stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery("SELECT * FROM userdata");

     pw.println("<html><body bgcolor='lavender'>");
     pw.println("<h2>User Data Table</h2>");
     pw.println("<table border='1'><tr><th>Name</th><th>Email</th><th>Mobile</th><th>Edit</th><th>Delete</th></tr>");

      while (rs.next()) {
    	  pw.println("<tr>");
    	  pw.println("<td>" + rs.getString("name") + "</td>");
    	  pw.println("<td>" + rs.getString("email") + "</td>");
    	  pw.println("<td>" + rs.getString("mobile") + "</td>");

    	  pw.println("<td>");
    	  pw.println("<form action='edit' method='post'>");
    	  pw.println("<input type='hidden' name='email' value='" + rs.getString("email") + "'>");
    	  pw.println("<button type='submit'>Edit</button>");
    	  pw.println("</form></td>");

    	  pw.println("<td>");
    	  pw.println("<form action='delete' method='post' onsubmit=\"return confirm('Are you sure to delete?');\">");
    	  pw.println("<input type='hidden' name='email' value='" + rs.getString("email") + "'>");
    	  pw.println("<button type='submit'>Delete</button>");
    	  pw.println("</form></td>");

    	  pw.println("</tr>");
      }

      pw.println("</table>");
      pw.println("</body></html>");

      con.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
